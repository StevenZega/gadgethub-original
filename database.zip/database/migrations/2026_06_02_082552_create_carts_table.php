<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('carts', function (Blueprint $table) {
            $table->id();
            // Menghubungkan keranjang dengan user yang sedang login
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            // Menghubungkan keranjang dengan produk gadget
            $table->foreignId('product_id')->constrained()->onDelete('cascade');
            // Jumlah gadget yang dibeli
            $table->integer('quantity')->default(1);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('carts');
    }
};