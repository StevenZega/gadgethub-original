@extends('admin.dashboard')

@section('content')
<div class="container">
    <div class="mb-3">
        <a href="{{ route('products.index') }}" class="btn-modern btn-sm py-2 px-3 fs-7" style="background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); backdrop-filter: blur(10px);">
            <i class="bi bi-arrow-left-short fs-5 m-0"></i> Kembali ke List
        </a>
    </div>

    <div class="card-modern overflow-hidden" style="border-radius: 15px;">
        <div class="row g-0 d-flex align-items-stretch">
            
            <div class="col-md-5 d-flex">
                <img src="{{ asset('storage/' . $product->image) }}" 
                     class="img-fluid w-100 h-100" 
                     alt="{{ $product->name }}"
                     style="object-fit: cover; min-height: 400px;">
            </div>
            
            <div class="col-md-7">
                <div class="card-body p-4">
                    <h1 class="fw-bold mb-3 text-white">{{ $product->name }}</h1>

                    <div class="mb-4">
                        <h6 class="fw-bold text-muted small">Deskripsi Produk</h6>
                        <p style="color:#cbd5e1;">{{ $product->description ?? 'Tidak ada deskripsi.' }}</p>
                    </div>

                    <div class="d-flex align-items-center gap-4 mb-4">
                        <div>
                            <h6 class="text-muted small mb-1">Stok</h6>
                            <p class="fw-bold mb-0 text-dark">{{ $product->stock ?? 0 }} pcs</p>
                        </div>
                        
                        <div style="border-left: 1px solid #dee2e6; height: 30px;"></div>

                        <div>
                        {{-- Logika Stok Konsisten: Habis, Hampir Habis, atau Tersedia --}}
                        @if($product->stock <= 0)
                            <span class="badge bg-danger px-3 py-2">Habis</span>
                        @elseif($product->stock <= 5)
                            <span class="badge bg-warning text-dark px-3 py-2">Hampir Habis: {{ $product->stock }}</span>
                        @else
                            <span class="badge bg-success px-3 py-2">Tersedia</span>
                        @endif
                        </div>
                    </div>

                    <hr class="my-4 text-muted opacity-25">

                    <div class="mb-4">
                        <h6 class="text-muted small mb-1">Harga Satuan</h6>
                        <h2 class="text-primary fw-bold">
                            Rp {{ number_format($product->price ?? 0, 0, ',', '.') }}
                        </h2>
                    </div>

                    <div class="card-modern mt-4">

                        <h5 class="fw-bold text-white mb-4">
                            <i class="bi bi-cpu-fill text-info"></i>
                            Spesifikasi Produk
                        </h5>

                        <div class="row">

                            <div class="col-md-6 mb-3">
                                <small class="text-secondary">Kategori</small>
                                <div class="text-white fw-semibold">
                                    {{ $product->category }}
                                </div>
                            </div>

                            <div class="col-md-6 mb-3">
                                <small class="text-secondary">Brand</small>
                                <div class="text-white fw-semibold">
                                    {{ $product->brand }}
                                </div>
                            </div>
                        </div>
                    </div>

                    @if($product->category == 'Hape')

                    <div class="row">

                        <div class="col-md-4 mb-3">
                            <small class="text-secondary">RAM</small>
                            <div class="text-white">{{ $product->ram }} GB</div>
                        </div>

                        <div class="col-md-4 mb-3">
                            <small class="text-secondary">Storage</small>
                            <div class="text-white">{{ $product->storage }} GB</div>
                        </div>

                        <div class="col-md-4 mb-3">
                            <small class="text-secondary">Baterai</small>
                            <div class="text-white">
                                {{ $product->battery_capacity }} mAh
                            </div>
                        </div>

                        <div class="col-md-6 mb-3">
                            <small class="text-secondary">Processor</small>
                            <div class="text-white">
                                {{ $product->processor }}
                            </div>
                        </div>

                        <div class="col-md-6 mb-3">
                            <small class="text-secondary">Kamera Belakang</small>
                            <div class="text-white">
                                {{ $product->rear_camera }}
                            </div>
                        </div>

                        <div class="col-md-12 mb-3">
                            <small class="text-secondary">Ukuran Layar</small>
                            <div class="text-white">
                                {{ $product->screen_size }}
                            </div>
                        </div>

                    </div>
                    @endif

                    @if($product->category == 'Laptop')

                    <div class="row">

                        <div class="col-md-4 mb-3">
                            <small class="text-secondary">RAM</small>
                            <div class="text-white">
                                {{ $product->ram }} GB
                            </div>
                        </div>

                        <div class="col-md-4 mb-3">
                            <small class="text-secondary">Storage</small>
                            <div class="text-white">
                                {{ $product->storage }} GB
                            </div>
                        </div>

                        <div class="col-md-4 mb-3">
                            <small class="text-secondary">OS</small>
                            <div class="text-white">
                                {{ $product->os }}
                            </div>
                        </div>

                        <div class="col-md-6 mb-3">
                            <small class="text-secondary">Processor</small>
                            <div class="text-white">
                                {{ $product->processor }}
                            </div>
                        </div>

                        <div class="col-md-6 mb-3">
                            <small class="text-secondary">VGA</small>
                            <div class="text-white">
                                {{ $product->vga }}
                            </div>
                        </div>
                    </div>
                    @endif

                    <div class="d-flex gap-2 pt-2">
                        <a href="{{ route('products.edit', $product->id) }}" class="btn btn-warning px-4 text-white fw-bold shadow-sm">Edit</a>
                        
                        {{-- Button Delete dengan SweetAlert2 --}}
                        <form id="delete-form-{{ $product->id }}" action="{{ route('products.destroy', $product->id) }}" method="POST">
                            @csrf
                            @method('DELETE')
                            <button type="button" class="btn btn-danger px-4 fw-bold shadow-sm" onclick="confirmDelete({{ $product->id }})">
                                Delete
                            </button>
                        </form>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

{{-- Script SweetAlert2 untuk konsistensi notifikasi --}}
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    function confirmDelete(id) {
        Swal.fire({
            title: 'Hapus Produk?',
            text: "Data ini akan dihapus secara permanen!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#dc3545',
            cancelButtonColor: '#6c757d',
            confirmButtonText: 'Ya, Hapus!',
            cancelButtonText: 'Batal',
            reverseButtons: true,
            background: '#ffffff',
            customClass: {
                popup: 'rounded-4 shadow',
                title: 'fw-bold text-dark'
            }
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('delete-form-' + id).submit();
            }
        });
    }
</script>
@endsection